<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$patient_name = $_POST['patient_name'];
		$age = $_POST['age'];
		$sex = $_POST['sex'];
		$address = $_POST['Address'];
		$phone_no = $_POST['PhoneNo'];
		$symptoms = $_POST['Symptoms'];
		$previousVisit = $_POST['PreviousVisit'];




		if(!empty($patient_name) && !empty($age) && !empty($sex) )
		{

			//save to database
			$user_id = random_num(20);
			$query = "insert into patient_details (Name,Age,Sex,Phone_No,Address,Symptoms,Previous_Visit) values ('$patient_name','$age' ,'$sex','$phone_no','$address','$symptoms','$previousVisit')";

			mysqli_query($con, $query);

			//header("Location: login.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}
?>



<!DOCTYPE html>
<html>
<head>
	<title>trial</title>
</head>

<style type="text/css">
	
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

</style>
<body>

	<form method="post" id="my_form">


<form method="post">
			<div style="font-size: 20px;margin: 10px;color: white;">Signup</div>

			<input id="text" type="text" name="patient_name">
			<input id="text" type="text" name="age">
			<input id="text" type="text" name="sex">
			<input id="text" type="text" name="PhoneNo">
			<input id="text" type="text" name="Address">
			<input id="text" type="text" name="Symptoms">
			<input id="text" type="text" name="PreviousVisit">

		
		<input id="button" type="submit" value="Signup"><br><br>
			
		</form>
	
     
      
        
        <!---  <td>
        <td>
            <input type="text" name="PhoneNo" />
        </td>
        <td>
            <input type="text" name="Address" />
        </td>
        <td>
            <input type="text" name="Symptoms" />
        </td>
        <td>
            <input type="text" name="PreviousVist" />
        </td> */
    </tr> --->
   



		


	</form>


</body>
</html>